export const loamDepBadsmoke = true;
